Z-Ray-LoS
=========

Z-Ray extension for LoS modules

#### Z-Ray
Z-Ray is an awesome resource from Zend Server that provides several information about the request, errors and the framework. It also has the possibility to add your own informations, so i added the StaticLogger messages to it.

More information can be seen [here](http://www.zend.com/en/products/server/z-ray-top-7-features).

Warning: The Z-Ray extensions works only on Zend Server 8 or greater.

##### Installation
With the new Zend Server 8.1.0, go to the Plugin tab, then Gallery and install the LoS plugin.